﻿namespace ArabizeCore.Utilities
{
    public class Settings
    {
        public string macrosPath;
        public int macrosPerPage = 1;
    }
}
